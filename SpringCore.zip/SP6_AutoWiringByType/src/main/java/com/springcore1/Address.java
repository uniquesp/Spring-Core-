package com.springcore1;

public class Address 
{		
	public Address() {
		System.out.println("Address Def. con_or");		
	}

	void print()
	{
		System.out.println("Print of Address");		
	}
}
