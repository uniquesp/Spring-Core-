package com.springcore1;

public class Address 
{
	public void disp()
	{
		System.out.println("Address Display");
	}
}
